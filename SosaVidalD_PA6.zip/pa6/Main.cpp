/*
David Sosa Vidal
CPSC 122
Professor Jacob Shea
Programming Assignment 6, Linked Lists
Main Function File
*/

#include "PA6.h"

int main() {
	runMusicManager();

	return 0;
}